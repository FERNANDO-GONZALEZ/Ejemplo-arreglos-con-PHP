<?php

if (isset($_POST['submit'])){
    operaciones($_POST['v1'],$_POST['v2'],$_POST['v3']);
}

function operaciones($A, $B, $C) {
            switch ($C) {
            case 'S':
                $suma = $A + $B;
                echo "La Suma entre $A  y  $B  da  $suma<br/>";
            break;
            case 'R':
                $resta = $A - $B;
                echo "La resta entre $A  y  $B  da  $resta<br/>";
            break;
            case 'M':
                $multiplicacion = $A * $B;
                echo "La multiplicación entre $A  y  $B  da  $multiplicacion<br/>";
            break;
            case 'D':
                $division = $A / $B;
                echo "La división entre $A  y  $B  da  $division<br/>";
            break;
            default:
            echo "Operación no permitida !";
            }
}
       /* }
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

?> 